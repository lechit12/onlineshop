package pl.onlineshop.onlineshop.entities;

public enum Role {
    ADMIN, USER;
}
